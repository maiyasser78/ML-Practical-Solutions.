# Machine Learning Practical Solutions

Solutions for the exercises and mini-projects in Practical Sheets 0, 1, and 2.

## Structure
- `PS0/ps0_solutions.py` — Python refresher exercises and mini-project
- `PS1/ps1_solutions.py` — classification exercises and Breast Cancer mini-project
- `PS2/ps2_solutions.py` — linear regression / gradient descent exercises and California Housing mini-project

## Requirements
```bash
pip install numpy pandas matplotlib scikit-learn
```

Run a file from its folder, for example:
```bash
python ps0_solutions.py
```

Notes:
- The California Housing dataset may need an internet connection the first time scikit-learn downloads it.
- Results can vary slightly with library versions and train/test split settings.
- These scripts are learning examples; read the comments and make sure you can explain the code before submitting.

- `PS3/ps3_solutions.py` — regularization, sigmoid/softmax, Ridge vs Lasso, and Diabetes mini-project.
